console.log("hello word");

    var a= 1;
    var b= 2;
    var R= a+b;
    console.log("resultado de la suma :" + R);

    console.log("hello space")
    Math.sqrt(9); // 3
    Math.sqrt(2); // 1.414213562373095

    Math.sqrt(1);  // 1
    Math.sqrt(0);  // 0
    Math.sqrt(-1); // NaN
console.log("resultado de la raiz Cuadrada:" + R);

console.log("hello space")
Number.isInteger(0);         // true
Number.isInteger(1);         // true
Number.isInteger(-100000);   // true
Number.isInteger(99999999999999999999999); // true

Number.isInteger(0.1);       // false
Number.isInteger(Math.PI);   // false

Number.isInteger(NaN);       // false
Number.isInteger(Infinity);  // false
Number.isInteger(-Infinity); // false
Number.isInteger('10');      // false
Number.isInteger(true);      // false
Number.isInteger(false);     // false
Number.isInteger([1]);       // false
console.log("Resultado de los numeros enteros:" + R);

console.log("hello space")
var c = 50000;
var j = 2;
var numerosPrimos = [];

for (; j < c; j++) {

  if (primo(j)) {
    numerosPrimos.push(j);
  }
  
}

console.log(numerosPrimos);

function primo(numero) {

  for (var i = 2; i < numero; i++) {

    if (numero % i === 0) {
      return false;
    }

  }

  return numero !== 1;
}
console.log("Resultado de los numeros Primos:" + R);


